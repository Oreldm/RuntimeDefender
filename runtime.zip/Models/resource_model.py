from dataclasses import dataclass


@dataclass
class ResourceModel:
    cpu: float
    memory: float
