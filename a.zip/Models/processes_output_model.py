class ProcessOutputModel:
    process_arr: list

    def __init__(self, output: str):
        pass
